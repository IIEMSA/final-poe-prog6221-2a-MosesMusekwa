﻿using System;
using System.Collections.Generic;
using System.Linq;

class Recipe
{
    public string Name;
    public List<Ingredient> Ingredients;
    public List<string> Steps;

    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public void AddIngredient(Ingredient ingredient)
    {
        Ingredients.Add(ingredient);
    }

    public void AddStep(string step)
    {
        Steps.Add(step);
    }

    public void PrintRecipe()
    {
        Console.WriteLine("Recipe: {0}", Name);

        Console.WriteLine("Ingredients:");
        foreach (Ingredient ingredient in Ingredients)
        {
            Console.WriteLine("{0} {1} {2}", ingredient.Quantity, ingredient.Unit, ingredient.Name);
        }

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < Steps.Count; i++)
        {
            Console.WriteLine("{0}. {1}", i + 1, Steps[i]);
        }

        double totalCalories = Ingredients.Sum(ingredient => ingredient.Calories);
        Console.WriteLine("Total Calories: {0}", totalCalories);

        if (totalCalories > 300)
        {
            Console.WriteLine("WARNING: This recipe exceeds 300 calories!");
        }
    }

    public void ScaleRecipe(double factor)
    {
        foreach (Ingredient ingredient in Ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    public void ResetQuantities()
    {
        foreach (Ingredient ingredient in Ingredients)
        {
            ingredient.ResetQuantity();
        }
    }

    public void ClearRecipe()
    {
        Ingredients.Clear();
        Steps.Clear();
    }
}

class Ingredient
{
    public string Name;
    public double Quantity;
    public string Unit;
    public int Calories;
    public string FoodGroup;

    public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
        Calories = calories;
        FoodGroup = foodGroup;
    }

    public void ResetQuantity()
    {
        Quantity = 0;
    }
}

class Program
{
    // Generic collection to store recipes
    static List<Recipe> recipes = new List<Recipe>();

    // Delegate to notify the user when a recipe exceeds 300 calories
    delegate void RecipeCalorieNotification(Recipe recipe);

    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("\nRecipe Creator:");
            Console.WriteLine("1. Add Recipe");
            Console.WriteLine("2. Filter Recipes");
            Console.WriteLine("3. Exit");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter recipe name: ");
                    string recipeName = Console.ReadLine();
                    Recipe recipe = new Recipe(recipeName);
                    AddIngredientsAndSteps(recipe);
                    recipes.Add(recipe);
                    break;

                case 2:
                    if (recipes.Count == 0)
                    {
                        Console.WriteLine("No recipes available.");
                        break;
                    }

                    Console.WriteLine("\nFilter Recipes:");
                    Console.WriteLine("1. Filter by Ingredient");
                    Console.WriteLine("2. Filter by Food Group");
                    Console.WriteLine("3. Filter by Maximum Calories");
                    Console.WriteLine("4. Return to Recipe Creator");

                    int filterChoice = int.Parse(Console.ReadLine());

                    switch (filterChoice)
                    {
                        case 1:
                            Console.Write("Enter ingredient name: ");
                            string ingredientName = Console.ReadLine();
                            List<Recipe> filteredRecipesByIngredient = recipes
                                .Where(recipe => recipe.Ingredients
                                    .Any(ingredient => ingredient.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase)))
                                .ToList();

                            PrintFilteredRecipes(filteredRecipesByIngredient);
                            break;

                        case 2:
                            Console.Write("Enter food group: ");
                            string foodGroup = Console.ReadLine();
                            List<Recipe> filteredRecipesByFoodGroup = recipes
                                .Where(recipe => recipe.Ingredients
                                    .Any(ingredient => ingredient.FoodGroup.Equals(foodGroup, StringComparison.OrdinalIgnoreCase)))
                                .ToList();

                            PrintFilteredRecipes(filteredRecipesByFoodGroup);
                            break;

                        case 3:
                            Console.Write("Enter maximum calories: ");
                            int maxCalories = int.Parse(Console.ReadLine());
                            List<Recipe> filteredRecipesByCalories = recipes
                                .Where(recipe => recipe.Ingredients
                                    .Sum(ingredient => ingredient.Calories) <= maxCalories)
                                .ToList();

                            PrintFilteredRecipes(filteredRecipesByCalories);
                            break;

                        case 4:
                            break;

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                    break;

                case 3:
                    Console.WriteLine("Exiting...");
                    return;

                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    static void AddIngredientsAndSteps(Recipe recipe)
    {
        while (true)
        {
            Console.WriteLine("\nAdd Ingredients and Steps:");
            Console.WriteLine("1. Add Ingredient");
            Console.WriteLine("2. Add Step");
            Console.WriteLine("3. Return to Recipe Creator");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter ingredient name: ");
                    string ingredientName = Console.ReadLine();
                    Console.Write("Enter quantity: ");
                    double quantity = double.Parse(Console.ReadLine());
                    Console.Write("Enter measurement unit: ");
                    string unit = Console.ReadLine();
                    Console.Write("Enter calories: ");
                    int calories = int.Parse(Console.ReadLine());
                    Console.Write("Enter food group: ");
                    string foodGroup = Console.ReadLine();

                    Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
                    recipe.AddIngredient(ingredient);
                    break;

                case 2:
                    Console.Write("Enter step: ");
                    string step = Console.ReadLine();
                    recipe.AddStep(step);
                    break;

                case 3:
                    return;

                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    static void PrintFilteredRecipes(List<Recipe> recipes)
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes found.");
            return;
        }

        Console.WriteLine("\nFiltered Recipes:");
        foreach (Recipe recipe in recipes)
        {
            recipe.PrintRecipe();
            Console.WriteLine("---------------------");
        }
    }
}


